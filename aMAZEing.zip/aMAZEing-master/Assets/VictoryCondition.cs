﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VictoryCondition : MonoBehaviour {

    public bool touched;
    public TextMesh victoryText;

    // Use this for initialization
    void Start () {
        touched = false;
    }
	
	// Update is called once per frame
	void Update () {
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player" && touched == false)
        {
            victoryText.text = "Victory !";
            touched = true;
        }
    }
}
